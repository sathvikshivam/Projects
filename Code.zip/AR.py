import cv2
import numpy as np
import mediapipe as mp
import time

blue_color = (255, 0, 0)  
circle_radius = 30  
circle_centers = [(100, 100), (300, 100), (500, 100),
                  (700, 100), (900, 100), (1100, 100)] 

mp_hands = mp.solutions.hands
hands = mp_hands.Hands()


cap = cv2.VideoCapture(0)

def is_point_inside_circle(point, center, radius):
    return np.sqrt((point[0] - center[0])**2 + (point[1] - center[1])**2) <= radius

start_time = 0

while True:
    ret, frame = cap.read()
    if not ret:
        break

    frame = cv2.flip(frame, 1)

    height, width, _ = frame.shape

    display_frame = frame.copy()

    for center in circle_centers:
        cv2.circle(display_frame, center, circle_radius, blue_color, -1)

    rgb_frame = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
    results = hands.process(rgb_frame)

    if results.multi_hand_landmarks:
        for hand_landmarks in results.multi_hand_landmarks:
            index_finger_tip = hand_landmarks.landmark[mp_hands.HandLandmark.INDEX_FINGER_TIP]
            index_finger_position = (int(index_finger_tip.x * width), int(index_finger_tip.y * height))
            
            for i, center in enumerate(circle_centers):
                if is_point_inside_circle(index_finger_position, center, circle_radius):
                    cv2.rectangle(display_frame, (center[0] - 20, center[1] + circle_radius + 10),
                                  (center[0] + 20, center[1] + circle_radius + 50), blue_color, -1)
                    cv2.putText(display_frame, str(i+1), (center[0] - 10, center[1] + circle_radius + 40),
                                cv2.FONT_HERSHEY_SIMPLEX, 1, (255, 255, 255), 2)
                    start_time = time.time()

            if time.time() - start_time >= 5:
                start_time = 0

    cv2.imshow("Interactive Circles", display_frame)

    if cv2.waitKey(1) & 0xFF == ord('q'):
        break

cap.release()
cv2.destroyAllWindows()
