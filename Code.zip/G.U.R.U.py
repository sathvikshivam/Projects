import subprocess
import wolframalpha
import pyttsx3
import tkinter
import json
import random
import operator
import speech_recognition as sr
import datetime
import wikipedia
import webbrowser
import os
import winshell
import pyjokes
import feedparser
import smtplib
import ctypes
import time
import requests
import shutil
import psutil
import pyautogui
from twilio.rest import Client
from clint.textui import progress
from ecapture import ecapture as ec
from bs4 import BeautifulSoup
import win32com.client as wincl
from urllib.request import urlopen
from pptx import Presentation
from pptx.util import Inches
import pywhatkit

random_number = random.randint(1, 14)

engine = pyttsx3.init('sapi5')
voices = engine.getProperty('voices')
engine.setProperty('voice', voices[1].id)


def speak(audio):
	engine.say(audio)
	engine.runAndWait()

def wishMe():
	hour = int(datetime.datetime.now().hour)
	if hour>= 0 and hour<12:
		speak("Good Morning Sir !")

	elif hour>= 12 and hour<18:
		speak("Good Afternoon Sir !")

	else:
		speak("Good Evening Sir !")

	assname =("Guru")
	speak("I am your Assistant")
	speak(assname)
	

def username():
	uname = "Sathvik"
	speak("Welcome")
	speak(uname)
	columns = shutil.get_terminal_size().columns
	
	print("#####################".center(columns))
	print("Welcome ", uname.center(columns))
	print("#####################".center(columns))
	
	speak("How can i Help you, Sir")

api_id = "4349T8-JK4J2WPATJ"

def takeCommand():
     
    r = sr.Recognizer()
     
    with sr.Microphone() as source:
         
        print("Listening...")
        r.pause_threshold = 1
        audio = r.listen(source)
        try:
                print("Processing...")   
                query = r.recognize_google(audio, language ='en-in')
			

  
        except Exception as e:
                print("Unable to Recognize your voice.") 
                return "None"
             
        return query

def sendEmail(to, content):
	server = smtplib.SMTP('smtp.gmail.com', 587)
	server.ehlo()
	server.starttls()
	
	server.login('sathvikshivam@gmail.com', 'awtksvoccwdilfca')
	server.sendmail('sathvikshivam@gmail.com', to, content)
	server.close()



def create_presentation():
    presentation = Presentation()

    slide_layout = presentation.slide_layouts[0]
    slide = presentation.slides.add_slide(slide_layout)

    title = slide.shapes.title
    speak("What should he title be?")
    title.text = takeCommand()
    filenameppt=title.text+".pptx"
    presentation.save("C:\\Users\\Sathvik S\\OneDrive\\Desktop\\Genius Universal Response Unit\\Files\\Presentations\\"+ filenameppt)
    os.startfile("C:\\Users\\Sathvik S\\OneDrive\\Desktop\\Genius Universal Response Unit\\Files\\Presentations\\" + filenameppt)

def convert_to_12_hour_format(time_str):
    try:
        hours, minutes = map(int, time_str.split(':'))
        am_pm = "AM" if hours < 12 else "PM"
        hours = hours % 12 if hours % 12 != 0 else 12
        return f"{hours:02d}:{minutes:02d} {am_pm}"
    except ValueError:
        return "Invalid time format"



def get_first_search_result(query):
    search_url = f"https://www.google.com/search?q={query}"
    
    response = requests.get(search_url)
    response.raise_for_status()  
    
    soup = BeautifulSoup(response.text, 'html.parser')
    
    first_result = soup.select_one('.tF2Cxc')
    
    if first_result:
        link = first_result.a['href']
        return link
    else:
        return None

def take_photo():
    cam = cv2.VideoCapture(0)
    ret, frame = cam.read()
    if ret:
        cv2.imshow("Take a photo", frame)
        cv2.imwrite("C:\\Users\\Sathvik S\\OneDrive\\Desktop\\Genius Universal Response Unit\\Files\\Images\\img.jpg", frame)
        cv2.waitKey(0)
        cv2.destroyAllWindows()
        speak("Photo has been captured.")
    else:
        speak("Camera not accessible.")


	
if __name__ == '__main__':
	clear = lambda: os.system('cls')
	

	clear()
	wishMe()
	username()
	
	while True:
		
		query = takeCommand().lower()
		

		if 'wikipedia' in query:
			speak('Searching Wikipedia...')
			query = query.replace("wikipedia", "")
			results = wikipedia.summary(query, sentences = 3)
			speak("According to Wikipedia")
			print(results)
			speak(results)

		if 'open presentation' in query:
			speak("What is the name of the presentation?")
			filenamep = takeCommand() + ".pptx"
			os.startfile("C:\\Users\\Sathvik S\\OneDrive\\Desktop\\Genius Universal Response Unit\\Files\\Presentations\\"+ filenamep)
		elif 'open youtube' in query:
			speak("Here you go to Youtube\n")
			webbrowser.open("youtube.com")

		elif 'open google' in query:
			speak("Here you go to Google\n")
			webbrowser.open("google.com")

		elif 'open stackoverflow' in query:
			speak("Here you go to Stack Over flow.Happy coding")
			webbrowser.open("stackoverflow.com")

		elif 'play my music' in query:
			speak("Here you go with music")
			music_dir = "C:\\Users\\Sathvik S\\Music"
			songs = os.listdir(music_dir)
			print(songs)
			random = os.startfile(os.path.join(music_dir, songs[random_number]))

		elif 'time' in query:
			strTime = datetime.datetime.now().strftime("%H:%M")
			time_12_hour = convert_to_12_hour_format(strTime)
			speak(f"Sir, the time is {time_12_hour}")

		elif 'email to dad' in query:
			try:
				speak("What should I say?")
				content = takeCommand()
				to = "svmadhu31@gmail.com"
				sendEmail(to, content)
				speak("Email has been sent !")
			except Exception as e:
				print(e)
				speak("I am not able to send this email")

		elif 'send a mail' in query:
			try:
				speak("What should I say?")
				content = takeCommand()
				speak("whom should i send it to?")
				to = input()
				sendEmail(to, content)
				speak("Email has been sent !")
			except Exception as e:
				print(e)
				speak("I am not able to send this email")

		elif 'how are you' in query:
			speak("I am fine, Thank you")
			speak("How are you, Sir")

		elif 'fine' in query or "good" in query:
			speak("It's good to know that your fine")

		elif "change my name to" in query:
			query = query.replace("change my name to", "")
			assname = query

		elif "change name" in query:
			speak("What would you like to call me, Sir ")
			assname = takeCommand()
			speak("Thanks for naming me")


		elif 'exit' in query:
			speak("Thanks for giving me your time")
			exit()

		elif "who made you" in query or "who created you" in query:
			speak("I have been created by Sathvik.")
			
		elif 'joke' in query:
			speak(pyjokes.get_joke())
			
		elif "calculate" in query:
			
			client = wolframalpha.Client(api_id)
			indx = query.lower().split().index('calculate')
			query = query.split()[indx + 1:]
			res = client.query(' '.join(query))
			answer = next(res.results).text
			print("The answer is " + answer)
			speak("The answer is " + answer)

		elif 'search' in query:
			
			query = query.replace("search", "")
			webbrowser.open(query)


		elif 'new presentation' in query:
			create_presentation()


		elif "who are you" in query:
			speak("I am your virtual assistant created by Sathvik")

		elif 'reason for you' in query:
			speak("I was created as a Minor project by Mister Sathvik ")

		elif 'news' in query:
				try:
						news_url = "https://news.google.com/news/rss"
						Client = urlopen(news_url)
						xml_page = Client.read()
						Client.close()
						soup_page = BeautifulSoup(xml_page, "xml")
						news_list = soup_page.findAll("item")
						for news in news_list[:15]:
							speak(news.title.text.encode('utf-8'))
				except Exception as e:
					print(e)

		
		elif 'lock window' in query:
				speak("locking the device")
				ctypes.windll.user32.LockWorkStation()

		elif 'shut down system' in query:
				speak("Hold On a Sec ! Your system is on its way to shut down")
				subprocess.call('shutdown / p /f')
				
		elif 'empty recycle bin' in query:
			winshell.recycle_bin().empty(confirm = False, show_progress = False, sound = True)
			speak("Recycle Bin Recycled")

		elif "where is" in query:
			query = query.replace("where is", "")
			location = query
			speak("User asked to Locate")
			speak(location)
			webbrowser.open("https://www.google.com/maps/place/"+ location + "")

		elif "camera" in query or "take a photo" in query:
			ec.capture(0, "Jarvis Camera ", "img.jpg")

		elif "restart" in query:
			subprocess.call(["shutdown", "/r"])
			
		elif "hibernate" in query or "sleep" in query:
			speak("Hibernating")
			subprocess.call("shutdown / h")

		elif "log off" in query or "sign out" in query:
			speak("Make sure all the application are closed before sign-out")
			time.sleep(5)
			subprocess.call(["shutdown", "/l"])
			
		
		elif "show note" in query:
			speak("Showing Notes")
			file = open("C:\\Users\\Sathvik S\\OneDrive\\Desktop\\Genius Universal Response Unit\\Files\\notes.txt", "r")
			print(file.read())
			speak(file.read())

		elif "open website" in query:
			webpage = query.replace("open website", "")
			webpage = webpage.replace(" ", "")
			webbrowser.open("www."+webpage+".com")

                        
					
		elif "guru" in query:
			
			wishMe()
			speak("The Genius Universal Response Unit is at your service")


		elif "weather" in query:
			api_key = "b2e107238388b8d35a5d58a1148dedfd"
			base_url = "http://api.openweathermap.org/data/2.5/weather?"
			city_name = "Aurora"
			complete_url = base_url + "appid=" + api_key + "&q=" + city_name
			response = requests.get(complete_url)
			data = response.json()

			if "cod" in data and data["cod"] == 200:
					weather_description = data["weather"][0]["description"]
					actual_temperature = data["main"]["temp"]
					actual_temperature_celsius = actual_temperature - 273.15  # Convert from Kelvin to Celsius
					print(f"Weather in {city_name}: {weather_description}")
					print(f"Actual Temperature: {actual_temperature_celsius:.2f} °C")
					speak(f"The weather in {city_name} has {weather_description}. The  temperature is {actual_temperature_celsius:.2f} degrees Celsius.")
			else:
				print("City not found or API error")
				speak("City not found or API error")
				


		elif "open wikipedia" in query:
			webbrowser.open("wikipedia.com")

		elif "Good Morning" in query:
			speak("A warm" +query)
			speak("How are you Mister")
			speak(assname)


			

		elif "what is" in query or "who is" in query:
			

			client = wolframalpha.Client(api_id)
			res = client.query(query)
			
			try:
				print (next(res.results).text)
				speak (next(res.results).text)
			except StopIteration:
				print ("No results")


				
		if "battery" in query:
                        battery = psutil.sensors_battery()
                        percent = battery.percent
                        speak(f"Battery is at {percent} percent")

		elif "write a note" in query:
                        speak("What should I write, sir?")
                        note = takeCommand()
                        file = open("C:\\Users\\Sathvik S\\OneDrive\\Desktop\\Genius Universal Response Unit\\Files\\notes.txt", 'w')
                        file.write(note)

		elif "gaming mode" in query:
				import pyautogui
				os.startfile("C:\\Users\\Sathvik S\\OneDrive\\Desktop\\Amazon Luna.lnk")
				time.sleep(4)
				pyautogui.click(-1542,703)
				time.sleep(4)
				pyautogui.click(-1673,475)
				time.sleep(4)
				pyautogui.click(1813,1048)
				time.sleep(4)
				pyautogui.click(1883,935)
				time.sleep(4)
				pyautogui.click(1678,751)
				time.sleep(4)
				pyautogui.click(-728,662)
				speak("enjoy gaming mode")
				input("Press enter to end gaming mode")
				pyautogui.click(-990,425)
				time.sleep(3)
				pyautogui.keyDown('esc')
				time.sleep(5)
				pyautogui.keyUp('esc')
				pyautogui.click(-18,13)
				time.sleep(4)
				pyautogui.click(-1673,475)
				time.sleep(4)
				pyautogui.click(1813,1048)
				time.sleep(4)
				pyautogui.click(1883,935)
				time.sleep(4)
				pyautogui.click(1678,761)
				speak("yes boss, i am working on it")
		elif "media mode" in query:
			import MediaPlayer
			speak("exiting media mode")
		
		elif 'volume up' in query:
			pyautogui.press('volumeup')
		
		elif 'volume down' in query:
			pyautogui.press('volumedown')
		elif 'pause' in query or "play" in query:
			pyautogui.press('playpause')
		if "play my music" not in query:
			if "play" in query:
				song = query.replace("play", "").strip()
				pywhatkit.playonyt(song)
				time.sleep(7)
				pyautogui.click(377,329)
				import MediaPlayer
		
		elif "take photo" in query:
			take_photo()
		
		elif "show me my photos" in query:
			webbrowser.open_new_tab('https://www.amazon.com/photos/all')


				

			

