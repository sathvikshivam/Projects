import os
os.system('cls')

print('Now we will begin to rearrange the code based on the filenames')

def replace_string_in_file(file_path, old_string, new_string):
    with open(file_path, 'r') as file:
        file_contents = file.read()
    
    file_contents = file_contents.replace(old_string, new_string)
    
    with open(file_path, 'w') as file:
        file.write(file_contents)

def process_python_files(folder_path, old_string, new_string):
    for root, _, files in os.walk(folder_path):
        for file in files:
            if file.endswith(".py"):
                file_path = os.path.join(root, file)
                replace_string_in_file(file_path, old_string, new_string)
                print(f'Replaced in {file_path}')


folder_path = input("Enter the folder path where the Python files are located: ")
old_string = "C:\\Users\\Sathvik S\\OneDrive\\Desktop"
new_string = input("Enter the new string to replace with: ")

process_python_files(folder_path, old_string, new_string)
