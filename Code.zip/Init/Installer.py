import subprocess
import os
import time
libraries = [
    'wolframalpha',
    'pyttsx3',
    'SpeechRecognition',
    'datetime',
    'wikipedia',
    'winshell',
    'pyjokes',
    'feedparser',
    'requests',
    'clint',
    'ecapture',
    'beautifulsoup4',
    'pywin32',
    'urllib3',
    'python-pptx',
    'librosa', 
    'numpy',
    'scikit-learn',
    'sounddevice',
    'pycaw',
    'opencv-python'

]

for library in libraries:
    try:
        os.system('cls')
        print(f"Installing {library}")
        subprocess.check_call(['pip', 'install', library])
        os.system('cls')
    
        print(f"Successfully installed {library}")
        time.sleep(1.5)
    except subprocess.CalledProcessError as e:
        print(f"Error installing {library}: {e}")
