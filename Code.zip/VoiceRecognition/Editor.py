import os
import librosa
import pyttsx3
import sounddevice as sd
import numpy as np
import soundfile as sf

def get_user_response():
    while True:
        response = input("Delete this pause? (yes/no): ").strip().lower()
        if response in {"yes", "no"}:
            return response == "yes"
        print("Invalid response. Please enter 'yes' or 'no'.")

def main():
    name = input("Please enter your name: ")
    folder = f"C:\\Users\\Sathvik S\\OneDrive\\Desktop\\Genius Universal Response Unit\\Voice Recognition\\{name}"
    print(f"Using folder: {folder}")

    engine = pyttsx3.init()
    ding_sound, sr_ding = librosa.load("ding.wav", sr=None)

    for filename in os.listdir(folder):
        if filename.endswith(".wav"):
            file_path = os.path.join(folder, filename)

            # Load the audio file
            audio, sr = librosa.load(file_path, sr=None)

            # Find pauses longer than 3 seconds
            pause_threshold = 3  # 3 seconds
            pauses = librosa.effects.split(audio, top_db=30, ref=np.median, frame_length=2048, hop_length=512)

            print(f"Processing {filename}...")

            # Track the number of pauses found
            num_pauses = len(pauses)
            print(f"Number of pauses found in {filename}: {num_pauses}")

            # Play the ding sound at the start of the first pause
            if len(pauses) > 0:
                first_pause_start = pauses[0][0]
                start_time = max(0, first_pause_start - 2 * sr)
                end_time = min(len(audio), first_pause_start)
                audio_segment = audio[start_time:end_time]
                sd.play(audio_segment, samplerate=sr)
                sd.wait()

            # Iterate through the pauses found
            pause_number = 1
            for pause_start, pause_end in pauses:
                pause_length = (pause_end - pause_start) / sr
                pause_start_sec = pause_start / sr

                # Speak the information about the pause
                engine.say(f"Playing pause {pause_number} from {filename}")
                engine.runAndWait()

                # Play the pause
                start_time = max(0, pause_start - 2 * sr)
                end_time = min(len(audio), pause_end + sr)
                audio_segment = audio[start_time:end_time]

                # Play the ding sound at the end of the pause
                sd.play(audio_segment, samplerate=sr)
                sd.wait()
                if pause_number < len(pauses):
                    next_pause_start = pauses[pause_number][0]
                    start_time = max(0, pause_end)
                    end_time = min(len(audio), next_pause_start)
                    audio_segment = audio[start_time:end_time]
                    sd.play(audio_segment, samplerate=sr)
                    sd.wait()

                # Ask user to delete the pause
                if get_user_response():
                    # Remove the pause from the original audio
                    audio = np.concatenate((audio[:pause_start], audio[pause_end:]))

                # Move on to the next pause
                pause_number += 1

            # Save the processed audio back to the file
            sf.write(file_path, audio, sr)

    print("Processing completed.")

if __name__ == "__main__":
    main()
