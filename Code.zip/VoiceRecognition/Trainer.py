import os
import sounddevice as sd
import wave
import time
import threading
import tkinter as tk

def get_next_available_filename(base_path, prefix):
    i = 1
    while True:
        file_path = os.path.join(base_path, f"{prefix}{i}.wav")
        if not os.path.exists(file_path):
            return file_path
        i += 1

def record_and_save_audio(base_path, prefix, duration=6, sr=22050):

    try:

        audio_data = sd.rec(int(duration * sr), samplerate=sr, channels=1, dtype='int16')
        sd.wait()

        file_path = get_next_available_filename(base_path, prefix)

        with wave.open(file_path, 'wb') as wf:
            wf.setnchannels(1)  
            wf.setsampwidth(2) 
            wf.setframerate(sr)
            wf.writeframes(audio_data.tobytes())
        print(f"Saved recording as {file_path}")
    except Exception as e:
        print(f"An error occurred: {e}")

def audio_recording_thread():
    record_and_save_audio(save_directory, prefix_name, duration=20, sr=44100)
    countdown_window.destroy()


def countdown(event):
    event.wait()  
    time.sleep(3)
    for i in range(20, 0, -1):
        print(f"{i} seconds remaining...", end='\r', flush=True)
        time.sleep(1)

def start_audio_recording(event):
    input("Press Enter To Start Recording...")
    
    for i in range(3, 0, -1):
        print(i)
        time.sleep(1)

    record_and_save_audio(save_directory, prefix_name, duration=20, sr=44100)

name = input("What is your name?: ")
while True:
    save_directory = f"C:\\Users\\Sathvik S\\OneDrive\\Desktop\\Genius Universal Response Unit\\Voice Recognition\\{name}"
    prefix_name = "Sample"

    event = threading.Event()

    countdown_thread = threading.Thread(target=countdown, args=(event,))
    recording_thread = threading.Thread(target=start_audio_recording, args=(event,))

    recording_thread.start()
    countdown_thread.start()

    countdown_thread.join()
    
    recording_thread.join()
