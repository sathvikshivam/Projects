import os
import librosa
import numpy as np
from sklearn.model_selection import train_test_split
from sklearn.svm import SVC
import sounddevice as sd
import wave


def record_and_save_audio(file_path, duration=6, sr=22050):

    try:
        audio_data = sd.rec(int(duration * sr), samplerate=sr, channels=1, dtype='int16')
        sd.wait()  # Wait for the recording to finish

        with wave.open(file_path, 'wb') as wf:
            wf.setnchannels(1)  
            wf.setsampwidth(2)  
            wf.setframerate(sr)
            wf.writeframes(audio_data.tobytes())
    except Exception as e:
        print(f"An error occurred: {e}")

def extract_mfcc(audio_path, num_mfcc=50):
    try:
#        print(f"Processing: {audio_path}")
        if not os.path.exists(audio_path):
#            print(f"Error: Audio file not found at {audio_path}")
            return None

        audio_data, sr = librosa.load(audio_path, sr=None)
#        print(f"Type of audio_data: {type(audio_data)}")
#        print(f"Length of audio data: {len(audio_data)}")
        
        if audio_data is not None and len(audio_data) > 0:
            mfccs = librosa.feature.mfcc(y=audio_data, sr=sr, n_mfcc=num_mfcc)
            return np.mean(mfccs, axis=1)
        else:
#            print(f"Error: Unable to load valid audio data from {audio_path}.")
            return None
    except Exception as e:
#        print(f"Error in extract_mfcc for {audio_path}: {e}")
        return None





def prepare_dataset(data_dir):
    audio_paths = []
    labels = []
    for speaker_folder in os.listdir(data_dir):
        speaker_path = os.path.join(data_dir, speaker_folder)
        if os.path.isdir(speaker_path):  # Check if the entry is a subdirectory
            for audio_file in os.listdir(speaker_path):
                audio_path = os.path.join(speaker_path, audio_file)
                audio_paths.append(audio_path)
                labels.append(speaker_folder)
   #             print(f"Added audio path: {audio_path}")
    return audio_paths, labels


def train_classifier(data_dir):
#    print("Preparing dataset...")
    audio_paths, labels = prepare_dataset(data_dir)

    X = []
    y = []

 #   print("Number of samples:", len(audio_paths))
 #   print("Number of labels:", len(labels))

    for audio_path, label in zip(audio_paths, labels):
        mfcc = extract_mfcc(audio_path)
        if mfcc is not None:
            X.append(mfcc)
            y.append(label)

    if not X or not y:
#        print("Error: Insufficient data for training the SVM model.")
        return None

    X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)

    if not X_train or not X_test or not y_train or not y_test:
#        print("Error: Data splitting failed. Insufficient data for training the SVM model.")
        return None

 #   print("Shape of X_train:", len(X_train), len(X_train[0]))
 #   print("Shape of X_test:", len(X_test), len(X_test[0]))
 #   print("Shape of y_train:", len(y_train))
 #   print("Shape of y_test:", len(y_test))

 #   print("Training SVM model...")
    svm = SVC(kernel='linear')
    svm.fit(X_train, y_train)

    accuracy = svm.score(X_test, y_test)
 #   print(f"Accuracy: {accuracy}")

    return svm

def predict_speaker(audio_path, classifier):
    mfcc = extract_mfcc(audio_path)
    if mfcc is not None:
        predicted_label = classifier.predict([mfcc])[0]
        return predicted_label
    else:
        return None
    
import sounddevice

def record_audio(duration=3, sr=22050):
    print("Please say 'Little Red Riding Hood Has A Basket'")
    record_and_save_audio("C:\\Users\\Sathvik S\\OneDrive\\Desktop\\Genius Universal Response Unit\\Sample1.wav")

if __name__ == "__main__":
    data_directory = "C:\\Users\\Sathvik S\\OneDrive\\Desktop\\Genius Universal Response Unit\\Voice Recognition"  # Replace with the path to your dataset directory
    classifier = train_classifier(data_directory)

    if classifier:
        while True:
            input("Press Enter to start recording...")
            record_audio()
            sample_audio_path = "C:\\Users\\Sathvik S\\OneDrive\\Desktop\\Genius Universal Response Unit\\Sample1.wav"  # Replace with the path to your sample audio
            predicted_speaker = predict_speaker(sample_audio_path, classifier)
            print(f"Predicted Speaker: {predicted_speaker}")
